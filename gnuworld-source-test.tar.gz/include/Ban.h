/* Ban.h */

#ifndef __BAN_H
#define __BAN_H

namespace gnuworld
{

class Ban
{

public:



protected:



} ;

} // namespace gnuworld

#endif // __BAN_H
